# Thực hành 05 — Tạo và quản lý nội dung số

## Mục tiêu
- Tạo trang HTML hiển thị nội dung đa phương tiện.
- Thực hành tổ chức tệp và quản lý phiên bản qua GitHub.
- Nhận biết cách ghi nguồn và tôn trọng bản quyền.

## Danh sách tệp
- `index.html`: Trang web giới thiệu chủ đề.
- `assets/infographic.png`: Infographic minh họa ứng dụng công nghệ số trong học tập.
- `assets/video.mp4`: Video minh họa ngắn về học tập số.
- `README.md`: Hướng dẫn và thông tin nguồn.

## Cách mở trang web
1. Tải toàn bộ thư mục về máy tính, giữ nguyên cấu trúc thư mục.
2. Mở `index.html` bằng Chrome hoặc Edge.
3. Ảnh và video được liên kết tương đối từ thư mục `assets`.

## Công cụ và nguồn
- Mã HTML và phần mô tả: được soạn với sự hỗ trợ của ChatGPT và chỉnh sửa cho bài thực hành.
- Infographic và video: được tạo riêng dưới dạng tài nguyên minh họa bằng công cụ lập trình.
- Không sử dụng tài nguyên bên thứ ba trong các tệp minh họa này.

## Bản quyền
Các tài nguyên minh họa trong gói được tạo riêng cho bài thực hành. Nếu bổ sung nội dung từ nguồn khác, hãy ghi tác giả, đường dẫn nguồn, giấy phép và các thay đổi. Chỉ ghi giấy phép CC BY khi có quyền cấp phép phù hợp; không tự động áp dụng CC BY cho tài nguyên của bên thứ ba.

## Thông tin sinh viên
- Họ tên: [Điền họ tên]
- Lớp: [Điền lớp]
- Repository GitHub: [Dán liên kết sau khi tải lên]
